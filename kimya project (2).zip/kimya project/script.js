/**
 * Campus Navigator - Core Application Logic
 * Supports:
 * 1. Maharashtra College Search & Filters (colleges.html)
 * 2. Dynamic College Details & Nearby Colleges (college-details.html)
 * 3. Interactive SVG Campus Map & Route Planner (index.html)
 * 4. Dynamic Department Details (department-details.html)
 */

document.addEventListener("DOMContentLoaded", function () {
    // Determine which page is currently active
    if (document.getElementById("collegesGrid")) {
        initCollegesPage();
    }

    if (document.getElementById("collegeDetailContent")) {
        initCollegeDetailsPage();
    }

    if (document.getElementById("campusSvgMap")) {
        initCampusNavigation();
    }

    if (document.getElementById("departmentDetailContent")) {
        initDepartmentDetailsPage();
    }
});

/* ===================================================
   1. MAHARASHTRA COLLEGE SEARCH (colleges.html)
=================================================== */

function initCollegesPage() {
    const collegesGrid = document.getElementById("collegesGrid");
    const searchInput = document.getElementById("searchCollegeInput");
    const districtFilter = document.getElementById("districtFilter");
    const typeFilter = document.getElementById("typeFilter");
    const resetBtn = document.getElementById("resetFiltersBtn");
    const countDisplay = document.getElementById("collegesCount");

    if (!collegesGrid) return;

    // Populate District Filter options dynamically
    if (districtFilter && window.COLLEGES_DATA) {
        const districts = [...new Set(window.COLLEGES_DATA.map(c => c.district))].sort();
        districts.forEach(dist => {
            const opt = document.createElement("option");
            opt.value = dist;
            opt.textContent = dist;
            districtFilter.appendChild(opt);
        });
    }

    // Filter event listeners
    function triggerFilter() {
        const query = (searchInput ? searchInput.value : "").trim().toLowerCase();
        const selectedDistrict = districtFilter ? districtFilter.value : "all";
        const selectedType = typeFilter ? typeFilter.value : "all";

        const filtered = window.COLLEGES_DATA.filter(col => {
            const matchesText =
                col.name.toLowerCase().includes(query) ||
                col.city.toLowerCase().includes(query) ||
                col.district.toLowerCase().includes(query) ||
                (col.shortName && col.shortName.toLowerCase().includes(query));

            const matchesDistrict = (selectedDistrict === "all") || (col.district === selectedDistrict);
            const matchesType = (selectedType === "all") || col.type.toLowerCase().includes(selectedType.toLowerCase());

            return matchesText && matchesDistrict && matchesType;
        });

        renderColleges(filtered);
    }

    if (searchInput) searchInput.addEventListener("input", triggerFilter);
    if (districtFilter) districtFilter.addEventListener("change", triggerFilter);
    if (typeFilter) typeFilter.addEventListener("change", triggerFilter);

    if (resetBtn) {
        resetBtn.addEventListener("click", function () {
            if (searchInput) searchInput.value = "";
            if (districtFilter) districtFilter.value = "all";
            if (typeFilter) typeFilter.value = "all";
            renderColleges(window.COLLEGES_DATA);
        });
    }

    // Initial render
    renderColleges(window.COLLEGES_DATA);

    function renderColleges(colleges) {
        if (countDisplay) {
            countDisplay.textContent = `${colleges.length} college${colleges.length === 1 ? '' : 's'}`;
        }

        if (colleges.length === 0) {
            collegesGrid.innerHTML = `
                <div class="empty-state">
                    <i class="fa-solid fa-building-circle-exclamation"></i>
                    <h3>No matching colleges found</h3>
                    <p>Try searching for a different city, college name, or district in Maharashtra.</p>
                </div>
            `;
            return;
        }

        collegesGrid.innerHTML = colleges.map(col => {
            const coursesPills = col.courses.slice(0, 3).map(c => `<span class="course-pill">${escapeHtml(c)}</span>`).join("");
            const hasMoreCourses = col.courses.length > 3 ? `<span class="course-pill">+${col.courses.length - 3} more</span>` : '';

            return `
                <div class="college-card">
                    <div class="card-top">
                        <div class="badge-row">
                            <span class="district-badge">
                                <i class="fa-solid fa-location-dot"></i> ${escapeHtml(col.city)}, ${escapeHtml(col.district)}
                            </span>
                            <span class="type-pill">${escapeHtml(col.type.split('&')[0].trim())}</span>
                        </div>
                        <h3>${escapeHtml(col.name)}</h3>
                        <p class="location-subtext">
                            <i class="fa-regular fa-compass"></i> Estd. ${escapeHtml(col.established)} | ${escapeHtml(col.affiliation.split('(')[0].trim())}
                        </p>
                        <div class="pills-container">
                            ${coursesPills}
                            ${hasMoreCourses}
                        </div>
                    </div>
                    <div class="card-footer-actions">
                        <a href="college-details.html?id=${encodeURIComponent(col.id)}" class="btn-primary" onclick="selectCollege('${col.id}', '${escapeJs(col.name)}', '${escapeJs(col.city)}')">
                            <i class="fa-solid fa-eye"></i> View Details
                        </a>
                        ${col.hasCampusMap ? `
                            <a href="index.html#navigation" class="btn-outline" title="Interactive Campus Navigation Available">
                                <i class="fa-solid fa-map-location-dot"></i> Inside Campus
                            </a>
                        ` : ''}
                    </div>
                </div>
            `;
        }).join("");
    }
}

// Global helper for college selection
function selectCollege(id, name, city) {
    if (typeof localStorage !== "undefined") {
        localStorage.setItem("selectedCollegeId", id);
        if (name) localStorage.setItem("selectedCollege", name);
        if (city) localStorage.setItem("selectedLocation", city);
    }
}

/* ===================================================
   2. COLLEGE DETAILS & NEARBY COLLEGES (college-details.html)
=================================================== */

function initCollegeDetailsPage() {
    const urlParams = new URLSearchParams(window.location.search);
    let collegeId = urlParams.get("id");

    // Fallback to localStorage if no URL query param
    if (!collegeId && typeof localStorage !== "undefined") {
        collegeId = localStorage.getItem("selectedCollegeId");
    }

    // Default fallback to first college if still not found
    let college = window.COLLEGES_DATA.find(c => c.id === collegeId);
    if (!college && window.COLLEGES_DATA.length > 0) {
        college = window.COLLEGES_DATA[0];
    }

    if (!college) return;

    // Save active ID
    if (typeof localStorage !== "undefined") {
        localStorage.setItem("selectedCollegeId", college.id);
        localStorage.setItem("selectedCollege", college.name);
        localStorage.setItem("selectedLocation", college.city);
    }

    // Update Page Title
    document.title = `${college.name} - Campus Details`;

    // Populate Hero Section
    const nameEl = document.getElementById("collegeName");
    if (nameEl) nameEl.textContent = college.name;

    const locationBadgeEl = document.getElementById("collegeLocationBadge");
    if (locationBadgeEl) locationBadgeEl.innerHTML = `<i class="fa-solid fa-location-dot"></i> ${escapeHtml(college.city)}, ${escapeHtml(college.district)}`;

    const typeBadgeEl = document.getElementById("collegeTypeBadge");
    if (typeBadgeEl) typeBadgeEl.textContent = college.type;

    const estdEl = document.getElementById("collegeEstd");
    if (estdEl) estdEl.innerHTML = `<i class="fa-solid fa-calendar"></i> Estd. ${escapeHtml(college.established)}`;

    const affiliationEl = document.getElementById("collegeAffiliation");
    if (affiliationEl) affiliationEl.innerHTML = `<i class="fa-solid fa-award"></i> ${escapeHtml(college.affiliation)}`;

    const descEl = document.getElementById("collegeDescription");
    if (descEl) descEl.textContent = college.description;

    // Contact Information
    const addressEl = document.getElementById("collegeAddress");
    if (addressEl) addressEl.textContent = college.address;

    const phoneEl = document.getElementById("collegePhone");
    if (phoneEl) {
        phoneEl.innerHTML = `<a href="tel:${escapeHtml(college.contact.phone)}">${escapeHtml(college.contact.phone)}</a>`;
    }

    const emailEl = document.getElementById("collegeEmail");
    if (emailEl) {
        emailEl.innerHTML = `<a href="mailto:${escapeHtml(college.contact.email)}">${escapeHtml(college.contact.email)}</a>`;
    }

    const websiteEl = document.getElementById("collegeWebsite");
    if (websiteEl) {
        if (college.website) {
            websiteEl.innerHTML = `<a href="${escapeHtml(college.website)}" target="_blank" rel="noopener noreferrer">${escapeHtml(college.website)} <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:12px; margin-left:4px;"></i></a>`;
        } else {
            websiteEl.textContent = "Website not available";
        }
    }

    // Courses List
    const coursesContainer = document.getElementById("collegeCoursesList");
    if (coursesContainer) {
        coursesContainer.innerHTML = college.courses.map(course => `
            <div class="course-item">
                <i class="fa-solid fa-graduation-cap"></i>
                <span>${escapeHtml(course)}</span>
            </div>
        `).join("");
    }

    // Facilities Grid
    const facilitiesContainer = document.getElementById("collegeFacilitiesList");
    if (facilitiesContainer) {
        facilitiesContainer.innerHTML = college.facilities.map(fac => `
            <div class="facility-card">
                <div class="facility-icon">
                    <i class="fa-solid ${fac.icon || 'fa-check'}"></i>
                </div>
                <div>
                    <h4>${escapeHtml(fac.name)}</h4>
                    <p>${escapeHtml(fac.desc || 'Available for students')}</p>
                </div>
            </div>
        `).join("");
    }

    // Departments List
    const deptsContainer = document.getElementById("collegeDepartmentsList");
    if (deptsContainer && college.departments) {
        deptsContainer.innerHTML = college.departments.map(dept => `
            <div class="dept-pill-item">
                <span>${escapeHtml(dept.name)}</span>
                <small>${escapeHtml(dept.floor || 'Campus')}</small>
            </div>
        `).join("");
    }

    // Navigation CTA Button
    const navCta = document.getElementById("campusNavCta");
    if (navCta) {
        if (college.hasCampusMap) {
            navCta.style.display = "inline-flex";
            navCta.href = "index.html#navigation";
            navCta.innerHTML = `<i class="fa-solid fa-map-location-dot"></i> Explore Inside Campus Map`;
        } else {
            navCta.style.display = "inline-flex";
            navCta.href = "index.html#navigation";
            navCta.innerHTML = `<i class="fa-solid fa-compass"></i> Explore Campus Navigation Model`;
        }
    }

    // Render Nearby Colleges
    renderNearbyColleges(college);
}

function renderNearbyColleges(currentCollege) {
    const nearbyContainer = document.getElementById("nearbyCollegesGrid");
    if (!nearbyContainer) return;

    let nearbyList = [];

    // Use predefined nearby IDs if available
    if (currentCollege.nearbyCollegeIds && currentCollege.nearbyCollegeIds.length > 0) {
        nearbyList = currentCollege.nearbyCollegeIds.map(item => {
            const col = window.COLLEGES_DATA.find(c => c.id === item.id);
            return col ? { college: col, distance: item.distance } : null;
        }).filter(Boolean);
    }

    // Fallback: If no explicit nearby IDs, find other colleges in the same or nearby district
    if (nearbyList.length === 0) {
        const sameDistrict = window.COLLEGES_DATA
            .filter(c => c.id !== currentCollege.id && c.district === currentCollege.district)
            .slice(0, 3)
            .map(c => ({ college: c, distance: "Nearby" }));

        const otherColleges = window.COLLEGES_DATA
            .filter(c => c.id !== currentCollege.id && c.district !== currentCollege.district)
            .slice(0, 3 - sameDistrict.length)
            .map(c => ({ college: c, distance: "Approx. region" }));

        nearbyList = [...sameDistrict, ...otherColleges];
    }

    if (nearbyList.length === 0) {
        nearbyContainer.innerHTML = `<p style="color:#64748b;">No other colleges registered in this immediate vicinity.</p>`;
        return;
    }

    nearbyContainer.innerHTML = nearbyList.map(item => `
        <div class="nearby-card">
            <div>
                <span class="nearby-distance">
                    <i class="fa-solid fa-route"></i> ${escapeHtml(item.distance)}
                </span>
                <h4>${escapeHtml(item.college.name)}</h4>
                <p>📍 ${escapeHtml(item.college.city)}, ${escapeHtml(item.college.district)}</p>
            </div>
            <a href="college-details.html?id=${encodeURIComponent(item.college.id)}" 
               class="btn-primary" 
               style="padding: 9px 14px; font-size: 13px;"
               onclick="selectCollege('${item.college.id}', '${escapeJs(item.college.name)}', '${escapeJs(item.college.city)}')">
                <i class="fa-solid fa-eye"></i> View Details
            </a>
        </div>
    `).join("");
}

/* ===================================================
   3. INTERACTIVE SVG CAMPUS NAVIGATION (index.html)
=================================================== */

function initCampusNavigation() {
    const svgMap = document.getElementById("campusSvgMap");
    const fromSelect = document.getElementById("navFromLocation");
    const toSelect = document.getElementById("navToLocation");
    const routeBtn = document.getElementById("getRouteBtn");
    const routeInfoPanel = document.getElementById("routeDirectionsPanel");
    const quickChips = document.querySelectorAll(".quick-chip");

    if (!svgMap || !window.CAMPUS_DATA) return;

    const nodes = window.CAMPUS_DATA.nodes;

    // Populate dropdowns if empty
    if (fromSelect && fromSelect.options.length <= 1) {
        fromSelect.innerHTML = Object.keys(nodes).map(key => {
            const n = nodes[key];
            return `<option value="${n.id}" ${n.id === 'gate' ? 'selected' : ''}>${n.icon} ${n.name}</option>`;
        }).join("");
    }

    if (toSelect && toSelect.options.length <= 1) {
        toSelect.innerHTML = Object.keys(nodes).map(key => {
            const n = nodes[key];
            return `<option value="${n.id}" ${n.id === 'comp' ? 'selected' : ''}>${n.icon} ${n.name}</option>`;
        }).join("");
    }

    // Attach click handlers to all SVG building groups
    const buildingGroups = svgMap.querySelectorAll(".map-building");
    buildingGroups.forEach(group => {
        group.addEventListener("click", function () {
            const nodeId = this.getAttribute("data-node");
            if (!nodeId || !nodes[nodeId]) return;

            // If start is the same as clicked, don't change
            const currentFrom = fromSelect ? fromSelect.value : "gate";
            if (currentFrom === nodeId) {
                alert(`You are already at ${nodes[nodeId].name}. Choose a different destination.`);
                return;
            }

            if (toSelect) {
                toSelect.value = nodeId;
            }

            drawCampusRoute(currentFrom, nodeId);
        });
    });

    // Handle "Get Directions" button
    if (routeBtn) {
        routeBtn.addEventListener("click", function () {
            const from = fromSelect ? fromSelect.value : "gate";
            const to = toSelect ? toSelect.value : "comp";
            drawCampusRoute(from, to);
        });
    }

    // Handle Quick Destination Chips
    quickChips.forEach(chip => {
        chip.addEventListener("click", function () {
            const targetNode = this.getAttribute("data-node");
            if (targetNode && nodes[targetNode]) {
                if (toSelect) toSelect.value = targetNode;
                const from = fromSelect ? fromSelect.value : "gate";
                drawCampusRoute(from, targetNode);
            }
        });
    });

    // Check if URL or localStorage specified an initial destination
    const urlParams = new URLSearchParams(window.location.search);
    const requestedTo = urlParams.get("to") || (typeof localStorage !== "undefined" ? localStorage.getItem("navDestination") : null);
    if (requestedTo && nodes[requestedTo]) {
        if (toSelect) toSelect.value = requestedTo;
        if (typeof localStorage !== "undefined") localStorage.removeItem("navDestination");
    }

    // Draw initial route (Default: gate -> comp)
    const initialFrom = fromSelect ? fromSelect.value : "gate";
    const initialTo = toSelect ? toSelect.value : "comp";
    drawCampusRoute(initialFrom, initialTo);
}

function drawCampusRoute(fromId, toId) {
    const svgMap = document.getElementById("campusSvgMap");
    const routePath = document.getElementById("activeRoutePath");
    const startPin = document.getElementById("startPin");
    const endPin = document.getElementById("endPin");
    const routeInfoPanel = document.getElementById("routeDirectionsPanel");

    if (!svgMap || !window.CAMPUS_DATA) return;

    const nodes = window.CAMPUS_DATA.nodes;
    const fromNode = nodes[fromId];
    const toNode = nodes[toId];

    if (!fromNode || !toNode) return;

    if (fromId === toId) {
        alert("Starting point and destination cannot be the same! Please pick different campus locations.");
        return;
    }

    // 1. Highlight buildings on map
    const allBuildings = svgMap.querySelectorAll(".map-building");
    allBuildings.forEach(b => {
        b.classList.remove("active-start", "active-destination");
        const id = b.getAttribute("data-node");
        if (id === fromId) b.classList.add("active-start");
        if (id === toId) b.classList.add("active-destination");
    });

    // 2. Lookup route or calculate coordinate path
    const routeKey = `${fromId}-${toId}`;
    const reverseRouteKey = `${toId}-${fromId}`;
    let routeData = window.CAMPUS_DATA.routes[routeKey];
    let isReversed = false;

    if (!routeData && window.CAMPUS_DATA.routes[reverseRouteKey]) {
        routeData = window.CAMPUS_DATA.routes[reverseRouteKey];
        isReversed = true;
    }

    let waypoints = [];
    let distance = "150 m";
    let walkingTime = "2 mins walk";
    let steps = [];

    if (routeData) {
        distance = routeData.distance;
        walkingTime = routeData.time;
        if (isReversed) {
            waypoints = [...routeData.path].reverse();
            steps = [
                `Depart from ${fromNode.name}.`,
                `Follow the return walkway towards the ${toNode.name}.`,
                `Arrive at ${toNode.name} (${toNode.building}, ${toNode.floor}).`
            ];
        } else {
            waypoints = routeData.path;
            steps = routeData.steps;
        }
    } else {
        // Fallback procedural path: from -> intermediate central hub -> to
        const midX = (fromNode.x + toNode.x) / 2;
        const midY = (fromNode.y + toNode.y) / 2;
        waypoints = [
            [fromNode.x, fromNode.y],
            [midX, fromNode.y],
            [midX, toNode.y],
            [toNode.x, toNode.y]
        ];
        distance = `${Math.round(Math.hypot(toNode.x - fromNode.x, toNode.y - fromNode.y) * 0.65)} m`;
        walkingTime = "2.5 mins walk";
        steps = [
            `Start at ${fromNode.name}.`,
            `Follow the connected campus walkway north/east toward the central concourse.`,
            `Walk towards ${toNode.building}.`,
            `Arrive at your destination: ${toNode.name} (${toNode.floor}).`
        ];
    }

    // 3. Render SVG Path
    if (waypoints.length > 0 && routePath) {
        const dStr = waypoints.reduce((acc, pt, idx) => {
            return idx === 0 ? `M ${pt[0]} ${pt[1]}` : `${acc} L ${pt[0]} ${pt[1]}`;
        }, "");
        routePath.setAttribute("d", dStr);
        routePath.style.display = "block";
    }

    // 4. Position Start and End Pins
    if (startPin) {
        startPin.setAttribute("transform", `translate(${fromNode.x}, ${fromNode.y - 12})`);
        startPin.style.display = "block";
    }
    if (endPin) {
        endPin.setAttribute("transform", `translate(${toNode.x}, ${toNode.y - 12})`);
        endPin.style.display = "block";
    }

    // 5. Render Step-by-Step Instructions in Panel
    if (routeInfoPanel) {
        routeInfoPanel.innerHTML = `
            <div class="route-summary-bar">
                <div class="route-headline">
                    <h3>
                        <span>${fromNode.icon} ${escapeHtml(fromNode.short || fromNode.name)}</span>
                        <i class="fa-solid fa-arrow-right" style="color:#2563eb; font-size:16px;"></i>
                        <span>${toNode.icon} ${escapeHtml(toNode.short || toNode.name)}</span>
                    </h3>
                </div>
                <div class="route-meta-stats">
                    <span class="stat-chip"><i class="fa-solid fa-person-walking"></i> Approx. ${escapeHtml(distance)}</span>
                    <span class="stat-chip"><i class="fa-regular fa-clock"></i> ${escapeHtml(walkingTime)}</span>
                    <span class="stat-chip" style="background:#ecfdf5; color:#065f46; border-color:#a7f3d0;"><i class="fa-solid fa-wheelchair"></i> Accessible Walkway</span>
                </div>
            </div>
            
            <div class="steps-list">
                ${steps.map((step, idx) => `
                    <div class="step-card">
                        <div class="step-number">${idx + 1}</div>
                        <div class="step-text">
                            <h4>${idx === 0 ? 'Starting Point' : (idx === steps.length - 1 ? 'Destination Reached' : `Step ${idx + 1}`)}</h4>
                            <p>${escapeHtml(step)}</p>
                        </div>
                    </div>
                `).join("")}
            </div>
        `;
    }
}

/* ===================================================
   4. DEPARTMENT SEARCH & DETAILS
=================================================== */

function searchDepartments() {
    const input = document.getElementById("departmentSearch");
    if (!input) return;

    const searchText = input.value.toLowerCase().trim();
    const cards = document.querySelectorAll(".department-card");

    cards.forEach(function (card) {
        const title = card.querySelector("h2") ? card.querySelector("h2").textContent.toLowerCase() : "";
        const desc = card.querySelector("p") ? card.querySelector("p").textContent.toLowerCase() : "";

        if (title.includes(searchText) || desc.includes(searchText)) {
            card.style.display = "flex";
        } else {
            card.style.display = "none";
        }
    });
}

function initDepartmentDetailsPage() {
    const urlParams = new URLSearchParams(window.location.search);
    const deptKey = urlParams.get("department") || "computer";

    if (!window.DEPARTMENTS_DATA) return;

    const dept = window.DEPARTMENTS_DATA[deptKey] || window.DEPARTMENTS_DATA.computer;
    if (!dept) return;

    document.title = `${dept.name} - Department Details`;

    const nameEl = document.getElementById("departmentName");
    if (nameEl) nameEl.textContent = dept.name;

    const descEl = document.getElementById("departmentDescription");
    if (descEl) descEl.textContent = dept.description;

    const iconEl = document.getElementById("departmentIcon");
    if (iconEl) iconEl.textContent = dept.icon;

    const buildingEl = document.getElementById("building");
    if (buildingEl) buildingEl.textContent = dept.building;

    const floorEl = document.getElementById("floor");
    if (floorEl) floorEl.textContent = dept.floor;

    const codeEl = document.getElementById("departmentCode");
    if (codeEl) codeEl.textContent = dept.code;

    const officeEl = document.getElementById("office");
    if (officeEl) officeEl.textContent = dept.office;

    // Classrooms
    const roomsContainer = document.getElementById("classroomsList");
    if (roomsContainer && dept.classrooms) {
        roomsContainer.innerHTML = dept.classrooms.map(c => `
            <li><strong>${escapeHtml(c.room)}</strong> — ${escapeHtml(c.type)} <span style="color:#64748b; font-size:12px;">(${escapeHtml(c.capacity)})</span></li>
        `).join("");
    }

    // Laboratories
    const labsContainer = document.getElementById("laboratoriesList");
    if (labsContainer && dept.laboratories) {
        labsContainer.innerHTML = dept.laboratories.map(l => `
            <li><strong>${escapeHtml(l.name)}</strong> (${escapeHtml(l.room)})<br><small style="color:#64748b;">${escapeHtml(l.desc)}</small></li>
        `).join("");
    }

    // Faculty
    const facultyContainer = document.getElementById("facultyList");
    if (facultyContainer && dept.faculty) {
        facultyContainer.innerHTML = dept.faculty.map(f => `
            <li><strong>${escapeHtml(f.name)}</strong> — ${escapeHtml(f.role)}<br><small style="color:#2563eb;">${escapeHtml(f.spec)}</small></li>
        `).join("");
    }

    // Navigation button
    const mapNavBtn = document.getElementById("navToDepartmentBtn");
    if (mapNavBtn && dept.mapNodeId) {
        mapNavBtn.href = `index.html?to=${encodeURIComponent(dept.mapNodeId)}#navigation`;
    }
}

/* ===================================================
   UTILITY HELPERS
=================================================== */
function escapeHtml(str) {
    if (str === null || str === undefined) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function escapeJs(str) {
    if (str === null || str === undefined) return "";
    return String(str).replace(/'/g, "\\'").replace(/"/g, '\\"');
}

// Global window bindings for HTML event handlers
if (typeof window !== "undefined") {
    window.searchDepartments = searchDepartments;
    window.selectCollege = selectCollege;
    window.drawCampusRoute = drawCampusRoute;
}