/**
 * Campus Navigator - Centralized Data Store
 * Contains Maharashtra colleges dataset, campus navigation nodes/paths, and department data.
 */

const COLLEGES_DATA = [
    {
        id: "srm-kudal",
        name: "Sant Rawool Maharaj Mahavidyalaya",
        shortName: "SRM College",
        city: "Kudal",
        district: "Sindhudurg",
        state: "Maharashtra",
        address: "S.N. Road, Near Kudal Railway Station, Kudal, Sindhudurg - 416528",
        type: "Arts, Science & Commerce",
        affiliation: "University of Mumbai (Accredited by NAAC)",
        established: "1984",
        website: "https://srmkudal.ac.in",
        contact: {
            phone: "+91 2362 222 242",
            email: "srmkudal@yahoo.co.in",
            principal: "Dr. S. D. Kulkarni"
        },
        description: "Sant Rawool Maharaj Mahavidyalaya is a premier educational institution in Sindhudurg, offering higher education across Arts, Science, Commerce, and Information Technology.",
        courses: [
            "B.Sc Computer Science",
            "B.Sc Information Technology",
            "B.Sc Chemistry / Physics / Botany",
            "B.Com (Financial Accounting)",
            "Bachelor of Management Studies (BMS)",
            "Bachelor of Arts (B.A)",
            "M.Sc Chemistry",
            "M.Com"
        ],
        departments: [
            { name: "Computer Science & IT", code: "CS-IT", floor: "2nd Floor" },
            { name: "Physics & Chemistry", code: "SCI", floor: "1st Floor" },
            { name: "Commerce & Accountancy", code: "COMM", floor: "Ground Floor" },
            { name: "Languages & Humanities", code: "ARTS", floor: "1st Floor" }
        ],
        facilities: [
            { name: "Central Library", icon: "fa-book", desc: "Over 45,000 reference books and digital journals" },
            { name: "Computer Center", icon: "fa-laptop-code", desc: "High-speed broadband and 120+ modern workstations" },
            { name: "Science Laboratories", icon: "fa-flask", desc: "Equipped labs for Chemistry, Physics, and Botany" },
            { name: "Auditorium", icon: "fa-users-line", desc: "500-seat multi-purpose hall for cultural & seminars" },
            { name: "Sports Complex", icon: "fa-volleyball", desc: "Open playground, gymkhana, and indoor games" },
            { name: "Campus Canteen", icon: "fa-utensils", desc: "Hygienic snacks, meals, and beverage cafeteria" },
            { name: "Hostel Facilities", icon: "fa-bed", desc: "Safe residential hostel accommodations" },
            { name: "Wi-Fi Campus", icon: "fa-wifi", desc: "High-speed campus-wide wireless connectivity" }
        ],
        hasCampusMap: true,
        nearbyCollegeIds: [
            { id: "sawantwadi-college", distance: "22 km" },
            { id: "vengurla-college", distance: "28 km" },
            { id: "gp-malvan", distance: "31 km" },
            { id: "sspm-kankavli", distance: "32 km" }
        ]
    },
    {
        id: "sspm-kankavli",
        name: "SSPM's College of Engineering",
        shortName: "SSPM COE",
        city: "Kankavli",
        district: "Sindhudurg",
        state: "Maharashtra",
        address: "A/P Harkul Budruk, Kankavli, Sindhudurg - 416602",
        type: "Engineering & Technology",
        affiliation: "University of Mumbai & Approved by AICTE",
        established: "1999",
        website: "https://sspmcoe.ac.in",
        contact: {
            phone: "+91 2367 231 525",
            email: "principal@sspmcoe.ac.in",
            principal: "Dr. M. G. Trivedi"
        },
        description: "SSPM's College of Engineering is the leading technical engineering institute in Sindhudurg, offering undergraduate and postgraduate engineering degree programs.",
        courses: [
            "B.Tech Computer Engineering",
            "B.Tech Mechanical Engineering",
            "B.Tech Civil Engineering",
            "B.Tech Electrical Engineering",
            "B.Tech Artificial Intelligence & Data Science",
            "M.Tech Computer Engineering"
        ],
        departments: [
            { name: "Computer Engineering", code: "COMP", floor: "2nd Floor" },
            { name: "Mechanical Engineering", code: "MECH", floor: "1st Floor" },
            { name: "Civil Engineering", code: "CIVIL", floor: "Ground Floor" },
            { name: "Electrical Engineering", code: "ELEC", floor: "3rd Floor" }
        ],
        facilities: [
            { name: "Robotics & AI Lab", icon: "fa-robot", desc: "Modern microcontrollers and robotics hardware" },
            { name: "Mechanical Workshops", icon: "fa-gears", desc: "CNC machines, lathe shop, and welding bays" },
            { name: "Digital Central Library", icon: "fa-book-open", desc: "IEEE digital explore subscriptions & book bank" },
            { name: "Boys & Girls Hostels", icon: "fa-building", desc: "On-campus secure residential buildings" },
            { name: "Campus Cafeteria", icon: "fa-utensils", desc: "Full dining hall serving student meals" },
            { name: "Seminar Halls", icon: "fa-chalkboard-user", desc: "Air-conditioned seminar and project presentation halls" }
        ],
        hasCampusMap: true,
        nearbyCollegeIds: [
            { id: "kankavli-college", distance: "4 km" },
            { id: "srm-kudal", distance: "32 km" },
            { id: "gp-malvan", distance: "45 km" }
        ]
    },
    {
        id: "sawantwadi-college",
        name: "Bhimrao Ambedkar Arts & Commerce College",
        shortName: "Sawantwadi College",
        city: "Sawantwadi",
        district: "Sindhudurg",
        state: "Maharashtra",
        address: "Charathe, Sawantwadi, Sindhudurg - 416510",
        type: "Arts & Commerce",
        affiliation: "University of Mumbai",
        established: "1992",
        website: "https://sawantwadicollege.ac.in",
        contact: {
            phone: "+91 2363 272 144",
            email: "contact@sawantwadicollege.ac.in",
            principal: "Dr. R. V. Parab"
        },
        description: "A prominent institution catering to students from southern Konkan, focusing on commerce, accounting, rural entrepreneurship, and liberal arts.",
        courses: [
            "Bachelor of Commerce (B.Com)",
            "Bachelor of Arts (B.A)",
            "Bachelor of Management Studies (BMS)",
            "Master of Commerce (M.Com - Advanced Accountancy)"
        ],
        departments: [
            { name: "Commerce & Accountancy", code: "COMM", floor: "Ground Floor" },
            { name: "Management Studies", code: "BMS", floor: "1st Floor" },
            { name: "Arts & Social Sciences", code: "ARTS", floor: "2nd Floor" }
        ],
        facilities: [
            { name: "Central Library", icon: "fa-book", desc: "Over 20,000 books and local Konkan history archives" },
            { name: "Computer Laboratory", icon: "fa-laptop", desc: "Tally, GST, and Accounting software terminals" },
            { name: "Gymkhana", icon: "fa-dumbbell", desc: "Physical fitness center and sports equipment" },
            { name: "Auditorium", icon: "fa-users", desc: "Cultural and inter-collegiate event hall" }
        ],
        hasCampusMap: false,
        nearbyCollegeIds: [
            { id: "srm-kudal", distance: "22 km" },
            { id: "vengurla-college", distance: "24 km" },
            { id: "sspm-kankavli", distance: "54 km" }
        ]
    },
    {
        id: "gp-malvan",
        name: "Government Polytechnic Malvan",
        shortName: "GP Malvan",
        city: "Malvan",
        district: "Sindhudurg",
        state: "Maharashtra",
        address: "Kumbharmath, Malvan, Sindhudurg - 416606",
        type: "Polytechnic / Diploma",
        affiliation: "Maharashtra State Board of Technical Education (MSBTE)",
        established: "1985",
        website: "https://gpmalvan.ac.in",
        contact: {
            phone: "+91 2365 252 223",
            email: "principal.gpmalvan@dtemaharashtra.gov.in",
            principal: "Prof. P. B. Sawant"
        },
        description: "Government Polytechnic Malvan is a state government technical polytechnic delivering top-tier practical engineering diploma programs on the coastal belt.",
        courses: [
            "Diploma in Computer Engineering",
            "Diploma in Civil Engineering",
            "Diploma in Mechanical Engineering",
            "Diploma in Electrical Engineering",
            "Diploma in Food Technology"
        ],
        departments: [
            { name: "Computer Engineering", code: "CO", floor: "2nd Floor" },
            { name: "Civil Engineering", code: "CE", floor: "Ground Floor" },
            { name: "Mechanical Engineering", code: "ME", floor: "Workshop Wing" }
        ],
        facilities: [
            { name: "Practical Workshops", icon: "fa-wrench", desc: "Machine tools, foundry, carpentry, and welding" },
            { name: "Surveying Lab", icon: "fa-compass-drafting", desc: "Total stations, theodolites, and leveling gear" },
            { name: "Computer Lab", icon: "fa-network-wired", desc: "LAN connected lab with Linux & CAD software" },
            { name: "Boys Hostel", icon: "fa-bed", desc: "Subsidized government hostel for students" }
        ],
        hasCampusMap: false,
        nearbyCollegeIds: [
            { id: "srm-kudal", distance: "31 km" },
            { id: "vengurla-college", distance: "42 km" },
            { id: "sspm-kankavli", distance: "45 km" }
        ]
    },
    {
        id: "vengurla-college",
        name: "Br. Balasaheb Khardekar College",
        shortName: "Vengurla College",
        city: "Vengurla",
        district: "Sindhudurg",
        state: "Maharashtra",
        address: "Bhatwadi, Vengurla, Sindhudurg - 416516",
        type: "Arts, Science & Commerce",
        affiliation: "University of Mumbai",
        established: "1961",
        website: "https://bbkcollegevengurla.ac.in",
        contact: {
            phone: "+91 2366 262 045",
            email: "bbkcollege@rediffmail.com",
            principal: "Dr. V. A. Patil"
        },
        description: "One of the oldest colleges in Sindhudurg, established in 1961, nestled amidst lush coastal coconut and mango orchards with renowned science research.",
        courses: [
            "B.Sc Chemistry, Botany, Zoology",
            "B.Sc Marine Biology / Fisheries",
            "Bachelor of Commerce (B.Com)",
            "Bachelor of Arts (B.A)",
            "M.Sc Organic Chemistry"
        ],
        departments: [
            { name: "Chemistry & Life Sciences", code: "SCI", floor: "Ground & 1st" },
            { name: "Commerce Department", code: "COMM", floor: "1st Floor" },
            { name: "Languages & History", code: "HUM", floor: "2nd Floor" }
        ],
        facilities: [
            { name: "Botanical Research Garden", icon: "fa-seedling", desc: "Over 150 Konkan indigenous floral species" },
            { name: "Marine Chemistry Lab", icon: "fa-flask-vial", desc: "Water quality and coastal ecology testing" },
            { name: "Heritage Library", icon: "fa-book-bookmark", desc: "Rare Konkani and Marathi literature collection" },
            { name: "Sports Oval", icon: "fa-volleyball", desc: "Cricket pitch and track-and-field grounds" }
        ],
        hasCampusMap: false,
        nearbyCollegeIds: [
            { id: "sawantwadi-college", distance: "24 km" },
            { id: "srm-kudal", distance: "28 km" },
            { id: "gp-malvan", distance: "42 km" }
        ]
    },
    {
        id: "kankavli-college",
        name: "Kankavli College Kankavli",
        shortName: "Kankavli College",
        city: "Kankavli",
        district: "Sindhudurg",
        state: "Maharashtra",
        address: "Vidyanagar, Kankavli, Sindhudurg - 416602",
        type: "Arts, Science & Commerce",
        affiliation: "University of Mumbai",
        established: "1972",
        website: "https://kankavlicollege.com",
        contact: {
            phone: "+91 2367 232 053",
            email: "kankavlicollege@yahoo.co.in",
            principal: "Dr. B. K. Shinde"
        },
        description: "Run by Shikshan Prasarak Mandal Kankavli, this institution provides holistic education to thousands of students across central Sindhudurg.",
        courses: [
            "B.Sc Computer Science",
            "B.Sc Physics, Chemistry, Mathematics",
            "Bachelor of Commerce (B.Com)",
            "Bachelor of Arts (B.A)",
            "Master of Arts (M.A - Marathi/History)"
        ],
        departments: [
            { name: "Science Faculty", code: "SCI", floor: "Ground Floor" },
            { name: "Commerce Faculty", code: "COMM", floor: "1st Floor" },
            { name: "Arts Faculty", code: "ARTS", floor: "2nd Floor" }
        ],
        facilities: [
            { name: "Central Library", icon: "fa-book", desc: "Spacious reading hall with competitive exam section" },
            { name: "Language Lab", icon: "fa-headphones", desc: "English language enhancement audio facility" },
            { name: "Auditorium", icon: "fa-building", desc: "Indoor auditorium for conventions" },
            { name: "Cafeteria", icon: "fa-utensils", desc: "Campus dining facility" }
        ],
        hasCampusMap: false,
        nearbyCollegeIds: [
            { id: "sspm-kankavli", distance: "4 km" },
            { id: "srm-kudal", distance: "32 km" }
        ]
    },
    {
        id: "dbj-chiplun",
        name: "D.B.J. College Chiplun",
        shortName: "DBJ College",
        city: "Chiplun",
        district: "Ratnagiri",
        state: "Maharashtra",
        address: "S.K. Patil Nagar, Chiplun, Ratnagiri - 415605",
        type: "Arts, Science & Commerce",
        affiliation: "University of Mumbai",
        established: "1965",
        website: "https://dbjcollege.org",
        contact: {
            phone: "+91 2355 252 088",
            email: "dbjcollege@gmail.com",
            principal: "Dr. S. C. Thakur"
        },
        description: "Dharamsi Morarji Rashtriya Shikshan Mandal's DBJ College is an 'A' grade NAAC accredited hub for higher education in the Chiplun sub-division.",
        courses: [
            "B.Sc Information Technology",
            "B.Sc Computer Science",
            "B.Com Banking & Insurance",
            "Bachelor of Management Studies (BMS)",
            "M.Sc Biotechnology"
        ],
        departments: [
            { name: "Information Technology", code: "IT", floor: "2nd Floor" },
            { name: "Commerce & Management", code: "MGMT", floor: "1st Floor" }
        ],
        facilities: [
            { name: "Biotech & IT Labs", icon: "fa-dna", desc: "Equipped for molecular biology and network programming" },
            { name: "E-Library", icon: "fa-computer", desc: "National Digital Library of India access nodes" },
            { name: "Girls Hostel", icon: "fa-hotel", desc: "Safe residential campus housing" }
        ],
        hasCampusMap: false,
        nearbyCollegeIds: [
            { id: "gogate-jogalekar", distance: "88 km" }
        ]
    },
    {
        id: "gogate-jogalekar",
        name: "Gogate Jogalekar College",
        shortName: "GJ College",
        city: "Ratnagiri",
        district: "Ratnagiri",
        state: "Maharashtra",
        address: "Adv. N.V. Joshi Road, Near District Court, Ratnagiri - 415612",
        type: "Arts, Science & Commerce",
        affiliation: "University of Mumbai (Autonomous)",
        established: "1945",
        website: "https://resgjc.edu.in",
        contact: {
            phone: "+91 2352 222 284",
            email: "principal@resgjc.edu.in",
            principal: "Dr. M. P. Deo"
        },
        description: "An autonomous heritage institution with NAAC 'A+' rating, offering 35+ undergraduate, postgraduate and doctoral research programs.",
        courses: [
            "B.Sc Computer Science & Data Science",
            "B.Sc Microbiology, Chemistry",
            "B.Com Accounting & Finance",
            "B.A Communication & Journalism",
            "M.Sc Analytical Chemistry",
            "Ph.D. Research Center"
        ],
        departments: [
            { name: "Computer & Mathematical Sciences", code: "CS", floor: "3rd Floor" },
            { name: "Physical & Biological Sciences", code: "SCI", floor: "Ground & 1st" },
            { name: "Commerce & Accountancy", code: "COMM", floor: "2nd Floor" }
        ],
        facilities: [
            { name: "Heritage Research Library", icon: "fa-book-bookmark", desc: "Over 100,000 volumes and digital manuscripts" },
            { name: "Research Instrumentation Center", icon: "fa-microscope", desc: "Spectrophotometers, HPLC, and incubator rooms" },
            { name: "Sports Pavilion", icon: "fa-trophy", desc: "Badminton courts, table tennis, and athletics" },
            { name: "Auditorium & Planetarium", icon: "fa-star", desc: "Digital star theater and assembly hall" }
        ],
        hasCampusMap: false,
        nearbyCollegeIds: [
            { id: "dbj-chiplun", distance: "88 km" },
            { id: "sspm-kankavli", distance: "85 km" }
        ]
    },
    {
        id: "coep-pune",
        name: "COEP Technological University",
        shortName: "COEP Tech",
        city: "Pune",
        district: "Pune",
        state: "Maharashtra",
        address: "Wellesley Rd, Shivajinagar, Pune - 411005",
        type: "Engineering & Technology",
        affiliation: "State Autonomous Technical University",
        established: "1854",
        website: "https://coeptech.ac.in",
        contact: {
            phone: "+91 20 2550 7000",
            email: "registrar@coeptech.ac.in",
            principal: "Prof. S. D. Agashe"
        },
        description: "COEP is the third oldest engineering college in Asia, a globally renowned technological university fostering innovation, patents, and engineering leaders.",
        courses: [
            "B.Tech Computer Engineering",
            "B.Tech Mechanical Engineering",
            "B.Tech Civil & Infrastructure",
            "B.Tech Electrical Engineering",
            "B.Tech Electronics & Telecommunication",
            "M.Tech & Ph.D. Research"
        ],
        departments: [
            { name: "Computer Engineering", code: "COMP", floor: "North Campus" },
            { name: "Mechanical Engineering", code: "MECH", floor: "South Campus" },
            { name: "Civil Engineering", code: "CIVIL", floor: "Main Heritage Block" }
        ],
        facilities: [
            { name: "Historic Main Hall & Clock Tower", icon: "fa-landmark", desc: "Victorian Gothic stone heritage campus" },
            { name: "COEP Boat Club", icon: "fa-ship", desc: "Famous boat club on the banks of Mula River" },
            { name: "Advanced Supercomputing Lab", icon: "fa-server", desc: "GPU computing clusters and AI testbeds" },
            { name: "Central Library", icon: "fa-book-atlas", desc: "Rare engineering archives and research access" }
        ],
        hasCampusMap: true,
        nearbyCollegeIds: [
            { id: "pict-pune", distance: "9 km" },
            { id: "fergusson-pune", distance: "3 km" }
        ]
    },
    {
        id: "fergusson-pune",
        name: "Fergusson College (Autonomous)",
        shortName: "Fergusson College",
        city: "Pune",
        district: "Pune",
        state: "Maharashtra",
        address: "F.C. Road, Shivajinagar, Pune - 411004",
        type: "Arts & Science",
        affiliation: "Savitribai Phule Pune University",
        established: "1885",
        website: "https://fergusson.edu",
        contact: {
            phone: "+91 20 6765 6000",
            email: "principal@fergusson.edu",
            principal: "Dr. N. B. Pawar"
        },
        description: "Fergusson College is a legendary temple of learning in Pune, founded by the Deccan Education Society, with an illustrious history of national leaders.",
        courses: [
            "B.Sc Computer Science",
            "B.Sc Physics, Chemistry, Geology",
            "B.Sc Biotechnology",
            "B.A Economics, Psychology, English",
            "M.Sc Computer Applications"
        ],
        departments: [
            { name: "Computer Science", code: "CS", floor: "Resolve Building" },
            { name: "Natural Sciences", code: "SCI", floor: "Science Quad" }
        ],
        facilities: [
            { name: "Bai Jerbai Wadia Library", icon: "fa-book-open", desc: "300,000+ historic books and manuscripts" },
            { name: "Amphitheatre", icon: "fa-masks-theater", desc: "Historic stone open-air cultural theatre" },
            { name: "Kimaya Student Open Canteen", icon: "fa-mug-hot", desc: "Iconic student cultural gathering point" }
        ],
        hasCampusMap: false,
        nearbyCollegeIds: [
            { id: "coep-pune", distance: "3 km" },
            { id: "pict-pune", distance: "8 km" }
        ]
    },
    {
        id: "pict-pune",
        name: "Pune Institute of Computer Technology (PICT)",
        shortName: "PICT Pune",
        city: "Pune",
        district: "Pune",
        state: "Maharashtra",
        address: "Survey No. 27, Near Trimurti Chowk, Dhankawadi, Pune - 411043",
        type: "Engineering & Technology",
        affiliation: "Savitribai Phule Pune University",
        established: "1983",
        website: "https://pict.edu",
        contact: {
            phone: "+91 20 2437 1101",
            email: "principal@pict.edu",
            principal: "Dr. P. T. Kulkarni"
        },
        description: "PICT is widely renowned across India as a premier center of excellence in Computer Engineering, Information Technology, and Artificial Intelligence.",
        courses: [
            "B.E Computer Engineering",
            "B.E Information Technology",
            "B.E Electronics & Telecommunication",
            "B.E Artificial Intelligence & Data Science",
            "M.E Computer Engineering"
        ],
        departments: [
            { name: "Computer Engineering", code: "COMP", floor: "Building A" },
            { name: "Information Technology", code: "IT", floor: "Building B" }
        ],
        facilities: [
            { name: "Specialized AI & Cloud Lab", icon: "fa-server", desc: "Enterprise computing labs and high-speed fiber" },
            { name: "Digital Central Library", icon: "fa-book", desc: "ACM, IEEE, and Springer digital repository" },
            { name: "Start-up & EDC Cell", icon: "fa-lightbulb", desc: "Active incubation and entrepreneurship center" }
        ],
        hasCampusMap: false,
        nearbyCollegeIds: [
            { id: "coep-pune", distance: "9 km" },
            { id: "fergusson-pune", distance: "8 km" }
        ]
    },
    {
        id: "vjti-mumbai",
        name: "Veermata Jijabai Technological Institute (VJTI)",
        shortName: "VJTI Mumbai",
        city: "Mumbai",
        district: "Mumbai",
        state: "Maharashtra",
        address: "H.R. Mahajani Marg, Matunga East, Mumbai - 400019",
        type: "Engineering & Technology",
        affiliation: "University of Mumbai (Autonomous)",
        established: "1887",
        website: "https://vjti.ac.in",
        contact: {
            phone: "+91 22 2419 8101",
            email: "director@vjti.ac.in",
            principal: "Dr. S. K. Mahajan"
        },
        description: "VJTI is an iconic premier technical institution in Mumbai with a 135+ year legacy in engineering research, industrial consultancies, and student placements.",
        courses: [
            "B.Tech Computer Engineering",
            "B.Tech Information Technology",
            "B.Tech Mechanical Engineering",
            "B.Tech Electrical & Power Systems",
            "Master of Computer Applications (MCA)",
            "M.Tech & Ph.D."
        ],
        departments: [
            { name: "Computer Engineering & IT", code: "CE-IT", floor: "Quad 3" },
            { name: "Mechanical & Production", code: "MECH", floor: "Main Building" }
        ],
        facilities: [
            { name: "High Performance Computing Lab", icon: "fa-microchip", desc: "NVIDIA DGX deep learning servers" },
            { name: "Centenary Central Library", icon: "fa-book", desc: "Comprehensive engineering digital catalogue" },
            { name: "Hostels & Sports Grounds", icon: "fa-futbol", desc: "Football ground, basketball and tennis courts" }
        ],
        hasCampusMap: true,
        nearbyCollegeIds: [
            { id: "coep-pune", distance: "148 km" }
        ]
    },
    {
        id: "rit-kolhapur",
        name: "Rajarambapu Institute of Technology (RIT)",
        shortName: "RIT Rajaramnagar",
        city: "Islampur / Kolhapur",
        district: "Kolhapur",
        state: "Maharashtra",
        address: "Rajaramnagar, Sakharale, Islampur, Kolhapur Region - 415414",
        type: "Engineering & Technology",
        affiliation: "Shivaji University Kolhapur",
        established: "1983",
        website: "https://ritindia.edu",
        contact: {
            phone: "+91 2342 220 329",
            email: "director@ritindia.edu",
            principal: "Dr. Sushma Kulkarni"
        },
        description: "An autonomous engineering institution in Western Maharashtra recognized for experiential learning, entrepreneurial incubation, and green campus.",
        courses: [
            "B.Tech Computer Science & Engineering",
            "B.Tech Mechanical Engineering",
            "B.Tech Civil Engineering",
            "B.Tech Electrical Engineering",
            "Master of Business Administration (MBA)"
        ],
        departments: [
            { name: "Computer Engineering", code: "CSE", floor: "Dome Building" },
            { name: "Mechanical Engineering", code: "MECH", floor: "Block B" }
        ],
        facilities: [
            { name: "Innovation & Incubation Hub", icon: "fa-lightbulb", desc: "Startup incubator and prototyping facility" },
            { name: "Central Knowledge Center", icon: "fa-book-bookmark", desc: "Automated digital library" },
            { name: "Gymnasium & Sports Complex", icon: "fa-dumbbell", desc: "Modern fitness equipment and courts" }
        ],
        hasCampusMap: false,
        nearbyCollegeIds: [
            { id: "sspm-kankavli", distance: "115 km" }
        ]
    }
];

/**
 * Interactive Campus Map Nodes & Graph Data
 * Coordinate space: 800 x 550 SVG viewBox
 */
const CAMPUS_DATA = {
    campusName: "Sindhudurg Central Campus (Model Navigation Map)",
    nodes: {
        gate: {
            id: "gate",
            name: "Main Entrance Gate",
            short: "Gate",
            category: "Entrance",
            x: 120,
            y: 480,
            building: "Security & Welcome Portal",
            floor: "Ground",
            icon: "🚪",
            description: "Main campus entrance on College Avenue with 24/7 security booth and visitor check-in."
        },
        admin: {
            id: "admin",
            name: "Administration Block",
            short: "Admin Block",
            category: "Administration",
            x: 150,
            y: 300,
            building: "Main Administrative Wing",
            floor: "Ground & 1st Floor",
            icon: "🏛️",
            description: "Houses Principal's Office, Student Accounts, Examination Cell, Registrar, and Enquiry Counter."
        },
        comp: {
            id: "comp",
            name: "Computer Department",
            short: "Computer Dept",
            category: "Academics",
            x: 320,
            y: 150,
            building: "Engineering Block A",
            floor: "2nd Floor (Rooms C-201 to C-208)",
            icon: "💻",
            description: "Computer Engineering, IT, High-Tech Programming Labs, Server Room, and HOD Office."
        },
        mech: {
            id: "mech",
            name: "Mechanical Department",
            short: "Mechanical Dept",
            category: "Academics",
            x: 540,
            y: 150,
            building: "Engineering Block B",
            floor: "1st Floor & Ground Workshops",
            icon: "⚙️",
            description: "Thermal Engineering Lab, CAD/CAM Studio, Machine Shop, and Mechanical Classrooms."
        },
        civil: {
            id: "civil",
            name: "Civil & Electrical Block",
            short: "Civil & Electrical",
            category: "Academics",
            x: 710,
            y: 220,
            building: "Technology Wing C",
            floor: "Ground & 3rd Floor",
            icon: "🏗️",
            description: "Geotechnical Lab, Surveying Lab, Electrical Power Systems, and Drawing Halls."
        },
        library: {
            id: "library",
            name: "Central Library",
            short: "Central Library",
            category: "Facilities",
            x: 330,
            y: 330,
            building: "Knowledge Resource Centre",
            floor: "1st & 2nd Floor",
            icon: "📚",
            description: "Reference Library, Silent Reading Hall, Digital E-Library, and Periodicals Section."
        },
        labs: {
            id: "labs",
            name: "Science & Central Labs",
            short: "Central Labs",
            category: "Academics",
            x: 530,
            y: 330,
            building: "Science Complex",
            floor: "Ground & 1st Floor",
            icon: "🧪",
            description: "Applied Physics Lab, Chemistry Research Lab, Electronics Circuits, and Project Spaces."
        },
        canteen: {
            id: "canteen",
            name: "Campus Canteen & Cafeteria",
            short: "Canteen",
            category: "Amenities",
            x: 710,
            y: 390,
            building: "Student Amenity Center",
            floor: "Ground Floor",
            icon: "☕",
            description: "Food court, tea counter, student seating garden, and fresh juice kiosk."
        },
        sports: {
            id: "sports",
            name: "Sports Ground & Gymkhana",
            short: "Sports Pavilion",
            category: "Recreation",
            x: 390,
            y: 480,
            building: "Athletic Pavilion",
            floor: "Ground Floor",
            icon: "⚽",
            description: "Multi-purpose sports ground, indoor table tennis, badminton court, and gymnasium."
        }
    },

    // Pathways defined as SVG points [x, y] and human directions
    routes: {
        "gate-admin": {
            path: [[120, 480], [120, 320], [150, 300]],
            distance: "75 m",
            time: "1 min walk",
            steps: [
                "Start at the Main Entrance Gate.",
                "Walk straight north along the Central Boulevard for 60 meters.",
                "Turn slightly right into the Administration Block portico."
            ]
        },
        "gate-comp": {
            path: [[120, 480], [120, 310], [190, 310], [190, 200], [320, 150]],
            distance: "190 m",
            time: "2.5 mins walk",
            steps: [
                "Exit the Main Gate and walk north past Administration.",
                "Turn right at the Academic Quad crossroads onto North Corridor.",
                "Head past the quad lawn towards Engineering Block A.",
                "Take Staircase A or the elevator to the 2nd Floor — Computer Department is directly ahead."
            ]
        },
        "gate-mech": {
            path: [[120, 480], [120, 310], [320, 310], [430, 220], [540, 150]],
            distance: "230 m",
            time: "3 mins walk",
            steps: [
                "Proceed from Main Gate north past Admin Wing.",
                "Follow Central Avenue through the central plaza.",
                "Walk northeast past Central Library towards Engineering Block B.",
                "Enter Mechanical Engineering foyer on the 1st Floor / Workshop bays on ground floor."
            ]
        },
        "gate-library": {
            path: [[120, 480], [120, 330], [250, 330], [330, 330]],
            distance: "130 m",
            time: "1.5 mins walk",
            steps: [
                "Walk north from Main Gate for 50 meters.",
                "Turn right onto Knowledge Way heading east.",
                "Arrive at the Central Library glass entrance on your right."
            ]
        },
        "gate-labs": {
            path: [[120, 480], [120, 330], [330, 330], [450, 330], [530, 330]],
            distance: "210 m",
            time: "2.5 mins walk",
            steps: [
                "Walk north along Central Boulevard and turn right at Library Junction.",
                "Continue east past the Library portico.",
                "Science & Central Labs complex will be straight ahead on your left."
            ]
        },
        "gate-civil": {
            path: [[120, 480], [120, 330], [450, 330], [600, 260], [710, 220]],
            distance: "270 m",
            time: "3.5 mins walk",
            steps: [
                "Start at Main Gate and head north past Administration.",
                "Follow Main East Avenue past the Library and Science Complex.",
                "Turn left into the Civil & Electrical Building court."
            ]
        },
        "gate-canteen": {
            path: [[120, 480], [250, 480], [450, 480], [620, 440], [710, 390]],
            distance: "240 m",
            time: "3 mins walk",
            steps: [
                "From Main Gate, walk east along South Perimeter Walkway.",
                "Walk along the edge of the Sports Pavilion.",
                "Arrive at the shaded open-air Campus Canteen courtyard."
            ]
        },
        "gate-sports": {
            path: [[120, 480], [240, 480], [390, 480]],
            distance: "110 m",
            time: "1.5 mins walk",
            steps: [
                "From Main Gate, take a right turn heading east.",
                "Walk 90 meters along the palm-lined Sports Walkway.",
                "Enter through the Sports Ground & Gymkhana pavilion gates."
            ]
        },
        "admin-comp": {
            path: [[150, 300], [190, 300], [190, 200], [320, 150]],
            distance: "125 m",
            time: "1.5 mins walk",
            steps: [
                "Exit Administration Block from North exit.",
                "Take North Walkway heading towards Engineering Block A.",
                "Take Stairway 1 to the 2nd Floor for Computer Department."
            ]
        },
        "admin-library": {
            path: [[150, 300], [240, 330], [330, 330]],
            distance: "85 m",
            time: "1 min walk",
            steps: [
                "Exit Admin Block east toward the central garden circle.",
                "Walk 70 meters east along Knowledge Way.",
                "Central Library is located directly across the central lawn."
            ]
        },
        "admin-canteen": {
            path: [[150, 300], [250, 330], [500, 330], [650, 370], [710, 390]],
            distance: "220 m",
            time: "2.5 mins walk",
            steps: [
                "Exit Admin Block east through the central walkway.",
                "Pass Central Library and Central Labs on your left.",
                "Follow the curved pathway to the Campus Canteen."
            ]
        },
        "comp-mech": {
            path: [[320, 150], [430, 150], [540, 150]],
            distance: "90 m",
            time: "1 min walk",
            steps: [
                "Exit Computer Department and take the 2nd floor sky-bridge or ground covered corridor.",
                "Walk east across the Engineering courtyard connecting Block A to Block B.",
                "Enter Mechanical Department reception on 1st Floor / Labs on ground."
            ]
        },
        "comp-library": {
            path: [[320, 150], [320, 240], [330, 330]],
            distance: "80 m",
            time: "1 min walk",
            steps: [
                "Take Staircase A down from Computer Department to ground level.",
                "Walk south across Academic Quad walkway.",
                "Central Library main entrance is 50 meters south."
            ]
        },
        "comp-labs": {
            path: [[320, 150], [430, 240], [530, 330]],
            distance: "115 m",
            time: "1.5 mins walk",
            steps: [
                "Exit Engineering Block A south-east.",
                "Follow the inter-department diagonal garden pathway.",
                "Enter Science & Central Labs ground floor entrance."
            ]
        },
        "comp-canteen": {
            path: [[320, 150], [450, 180], [630, 260], [710, 390]],
            distance: "210 m",
            time: "2.5 mins walk",
            steps: [
                "Head south-east past Engineering Block B and Civil Block.",
                "Follow the walkway towards the student amenity zone.",
                "Arrive at the Campus Canteen patio."
            ]
        },
        "library-comp": {
            path: [[330, 330], [320, 240], [320, 150]],
            distance: "80 m",
            time: "1 min walk",
            steps: [
                "Exit Central Library north onto the Academic Lawn pathway.",
                "Enter Engineering Block A.",
                "Take Staircase or Elevator to 2nd Floor for Computer Department."
            ]
        },
        "library-labs": {
            path: [[330, 330], [430, 330], [530, 330]],
            distance: "75 m",
            time: "1 min walk",
            steps: [
                "Exit Library and walk east along Knowledge Way.",
                "Cross the garden avenue to enter Science & Central Labs."
            ]
        },
        "library-canteen": {
            path: [[330, 330], [530, 330], [640, 360], [710, 390]],
            distance: "150 m",
            time: "2 mins walk",
            steps: [
                "Walk east from Central Library past Science Complex.",
                "Turn right towards Student Amenity Center.",
                "Canteen is located ahead on ground floor."
            ]
        },
        "mech-canteen": {
            path: [[540, 150], [640, 220], [710, 320], [710, 390]],
            distance: "120 m",
            time: "1.5 mins walk",
            steps: [
                "Exit Mechanical Department through south gate.",
                "Pass Civil & Electrical Wing.",
                "Enter Campus Canteen directly ahead."
            ]
        },
        "sports-canteen": {
            path: [[390, 480], [550, 480], [660, 440], [710, 390]],
            distance: "135 m",
            time: "1.5 mins walk",
            steps: [
                "Walk east from Sports Pavilion along tree-lined avenue.",
                "Turn left at the gazebo into Canteen courtyard."
            ]
        }
    }
};

/**
 * Detailed Department Profiles
 */
const DEPARTMENTS_DATA = {
    computer: {
        id: "computer",
        name: "Computer Engineering & IT",
        code: "CSE / IT",
        icon: "💻",
        building: "Engineering Block A",
        floor: "2nd Floor",
        office: "Room C-201 (HOD Office)",
        mapNodeId: "comp",
        description: "Department of Computer Engineering and Information Technology focuses on modern computing, software engineering, databases, algorithms, artificial intelligence, and cloud computing.",
        classrooms: [
            { room: "C-201", type: "Lecture Hall (Smart Board)", capacity: "75 seats" },
            { room: "C-202", type: "Lecture Hall", capacity: "75 seats" },
            { room: "C-203", type: "Tutorial & Seminar Room", capacity: "45 seats" },
            { room: "C-204", type: "Interactive Classroom", capacity: "60 seats" }
        ],
        laboratories: [
            { name: "Programming & Data Structures Lab", room: "C-205", desc: "40 Dell workstations, Linux/GCC environment" },
            { name: "Database & Web Engineering Lab", room: "C-206", desc: "PostgreSQL, MongoDB, Node.js development stack" },
            { name: "Computer Networks & Security Lab", room: "C-207", desc: "Cisco Routers, Packet Tracer & Wireshark testbeds" },
            { name: "AI, Machine Learning & Project Lab", room: "C-208", desc: "NVIDIA RTX GPUs, Python AI libraries, IoT kits" }
        ],
        faculty: [
            { name: "Dr. A. B. Kulkarni", role: "Head of Department (Professor)", spec: "Distributed Systems & Cloud Computing" },
            { name: "Prof. S. R. Desai", role: "Associate Professor", spec: "Database Systems & Data Mining" },
            { name: "Prof. M. N. Joshi", role: "Assistant Professor", spec: "Artificial Intelligence & NLP" },
            { name: "Prof. P. V. Rane", role: "Assistant Professor", spec: "Computer Networks & Cyber Security" }
        ]
    },
    mechanical: {
        id: "mechanical",
        name: "Mechanical Engineering",
        code: "MECH",
        icon: "⚙️",
        building: "Engineering Block B",
        floor: "1st Floor & Ground Workshops",
        office: "Room M-101 (HOD Office)",
        mapNodeId: "mech",
        description: "Mechanical Engineering deals with thermodynamics, robotics, machine design, fluid mechanics, CAD/CAM automation, and manufacturing technology.",
        classrooms: [
            { room: "M-101", type: "Lecture Hall", capacity: "80 seats" },
            { room: "M-102", type: "Lecture Hall", capacity: "80 seats" },
            { room: "M-103", type: "Drawing Hall", capacity: "90 drawing tables" }
        ],
        laboratories: [
            { name: "CAD/CAM Simulation Lab", room: "M-105", desc: "CATIA, AutoCAD & ANSYS engineering workstations" },
            { name: "Thermal Engineering & IC Engine Lab", room: "M-002 (Ground)", desc: "Multi-cylinder test rigs & exhaust gas analyzers" },
            { name: "Fluid Mechanics & Machinery Lab", room: "M-003 (Ground)", desc: "Pelton wheel, Francis turbine, venturimeters" },
            { name: "Central Machine Workshop", room: "Workshop Bay", desc: "Lathes, shapers, milling machines & CNC trainer" }
        ],
        faculty: [
            { name: "Dr. V. K. Sawant", role: "Head of Department (Professor)", spec: "Thermal Systems & Renewable Energy" },
            { name: "Prof. R. T. Patil", role: "Associate Professor", spec: "Machine Design & Finite Element Analysis" },
            { name: "Prof. K. S. Prabhu", role: "Assistant Professor", spec: "Manufacturing Processes & Robotics" }
        ]
    },
    civil: {
        id: "civil",
        name: "Civil Engineering",
        code: "CIVIL",
        icon: "🏗️",
        building: "Civil Block",
        floor: "Ground & 1st Floor",
        office: "Room CV-101",
        mapNodeId: "civil",
        description: "Civil Engineering encompasses structural design, geotechnical studies, transportation, environmental engineering, surveying, and earthquake-resistant structures.",
        classrooms: [
            { room: "CV-101", type: "Lecture Hall", capacity: "70 seats" },
            { room: "CV-102", type: "Lecture Hall", capacity: "70 seats" }
        ],
        laboratories: [
            { name: "Strength of Materials Lab", room: "CV-001", desc: "Universal Testing Machine (UTM), compression tests" },
            { name: "Surveying & Geomatics Lab", room: "CV-002", desc: "Digital Theodolites, Total Stations, GPS units" },
            { name: "Environmental Engineering Lab", room: "CV-003", desc: "Water and wastewater quality testing apparatus" },
            { name: "Geotechnical Engineering Lab", room: "CV-004", desc: "Direct shear, triaxial, and soil permeability test rigs" }
        ],
        faculty: [
            { name: "Prof. S. M. Gawade", role: "Head of Department", spec: "Structural Engineering & Concrete Tech" },
            { name: "Prof. N. D. Kamat", role: "Assistant Professor", spec: "Geotechnical & Foundation Engineering" },
            { name: "Prof. A. S. Parab", role: "Assistant Professor", spec: "Surveying & GIS Mapping" }
        ]
    },
    electrical: {
        id: "electrical",
        name: "Electrical Engineering",
        code: "ELEC",
        icon: "⚡",
        building: "Engineering Block B / Wing C",
        floor: "3rd Floor",
        office: "Room E-301",
        mapNodeId: "civil",
        description: "Department focused on electrical machines, high voltage transmission, renewable power grids, microcontrollers, and modern power electronics.",
        classrooms: [
            { room: "E-301", type: "Lecture Room", capacity: "65 seats" },
            { room: "E-302", type: "Smart Classroom", capacity: "65 seats" }
        ],
        laboratories: [
            { name: "Electrical Machines Lab", room: "E-304", desc: "AC/DC motor generator sets, synchronization panels" },
            { name: "Power Electronics & Drives Lab", room: "E-305", desc: "SCR, IGBT converters, inverter drive systems" },
            { name: "Control Systems & Microcontroller Lab", room: "E-306", desc: "PLC trainers, MATLAB/Simulink terminals, Arduino kits" }
        ],
        faculty: [
            { name: "Dr. H. P. Naik", role: "Head of Department", spec: "Power Systems & Smart Grids" },
            { name: "Prof. T. G. Jadhav", role: "Assistant Professor", spec: "Electrical Machines & Drives" }
        ]
    },
    science: {
        id: "science",
        name: "Basic Sciences & Humanities",
        code: "SCI",
        icon: "🔬",
        building: "Science Complex",
        floor: "Ground & 1st Floor",
        office: "Room S-101",
        mapNodeId: "labs",
        description: "Lays foundational scientific rigor in Applied Physics, Applied Chemistry, Engineering Mathematics, and Professional Communication Skills.",
        classrooms: [
            { room: "S-101", type: "Amphitheater Lecture Hall", capacity: "120 seats" },
            { room: "S-102", type: "Classroom", capacity: "80 seats" },
            { room: "S-103", type: "Classroom", capacity: "80 seats" }
        ],
        laboratories: [
            { name: "Applied Physics Laboratory", room: "S-005", desc: "He-Ne lasers, spectrometer setups, Hall effect probes" },
            { name: "Applied Chemistry Laboratory", room: "S-006", desc: "Fume hoods, conductometers, colorimeters" },
            { name: "Digital Language Lab", room: "S-108", desc: "Acoustic booths for presentation & soft-skills training" }
        ],
        faculty: [
            { name: "Dr. Mrs. S. V. Kelkar", role: "Head of Sciences", spec: "Applied Physics & Material Science" },
            { name: "Dr. P. R. Joshi", role: "Associate Professor", spec: "Organic & Environmental Chemistry" },
            { name: "Prof. D. K. Mane", role: "Assistant Professor", spec: "Applied Mathematics" }
        ]
    },
    management: {
        id: "management",
        name: "Management Studies (BMS / MBA)",
        code: "MGMT",
        icon: "📊",
        building: "Management Block (Admin Wing)",
        floor: "1st Floor",
        office: "Room MGT-101",
        mapNodeId: "admin",
        description: "Empowering business acumen, financial analysis, marketing strategies, entrepreneurship, and organizational management.",
        classrooms: [
            { room: "MGT-101", type: "Executive Classroom", capacity: "60 executive chairs" },
            { room: "MGT-102", type: "Case Study & Group Discussion Room", capacity: "40 seats" }
        ],
        laboratories: [
            { name: "Business Analytics & Financial Modeling Lab", room: "MGT-104", desc: "Excel financial modelling, SPSS statistics suite" }
        ],
        faculty: [
            { name: "Dr. C. N. Bhat", role: "Head of Management", spec: "Strategic Marketing & Rural Business" },
            { name: "Prof. S. S. Shirodkar", role: "Assistant Professor", spec: "Corporate Finance & Taxation" }
        ]
    }
};

// Export to global scope
if (typeof window !== "undefined") {
    window.COLLEGES_DATA = COLLEGES_DATA;
    window.CAMPUS_DATA = CAMPUS_DATA;
    window.DEPARTMENTS_DATA = DEPARTMENTS_DATA;
}
